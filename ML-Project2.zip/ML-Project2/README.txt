1. Download the GitHub repository: https://github.com/txu16/ML-Project2
2. In IntelliJ, open the folder ML-Project2-master
3. For part one, run the IncomeTest.java
	3a. To modify the algorithms and configurations, change the size of networks[], nnop[], and oa[] variables to the number of algorithms you want to run.
	3b. Then add the names of the algorithms to the oaNames array
	3c. Under the while loop, set each index in oa to be whichever algorithm you want to run with the specific hyperparameters passed in as the parameters; model after the code to see how to format
4. For part two, run which ever test you would like (FlipFlopTest.java, FourPeaksTest.java, or TravelingSalesmanTest.java)
